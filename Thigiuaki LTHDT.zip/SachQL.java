import java.util.ArrayList;

public class Quanlysach {
    private ArrayList<Sach> sachs;

    public Quanlysach() {
        sachs = new ArrayList<>();  
    }

    public void hienthi() {
        if (sachs.isEmpty()) {
            System.out.println("Danh sách sách hiện tại rỗng.");
        } else {
            for (Sach s : sachs) {
                System.out.println(s);  
            }
        }
    }

    
    public void addSach(Sach sach) {
        sachs.add(sach);
        System.out.println("Sách đã được thêm vào danh sách.");
    }

    
    public void suaSachTheoId(String id, String tenMoi, String tacGiaMoi, String nhaXuatBan) {
        for (Sach sach : sachs) {
            if (sach.getId().equals(id)) {
                sach.setTenSach(tenMoi);          // Cập nhật tên sách
                sach.setTacGia(tacGiaMoi);        // Cập nhật tên tác giả
                sach.setNhaXuatBan(nhaXuatBan);   // Cập nhật nhà xuất bản (sửa phương thức setNhaXuatBan)
                System.out.println("Thông tin sách đã được cập nhật.");
                return;  // Dừng vòng lặp sau khi sửa xong
            }
        }
        System.out.println("Không tìm thấy sách với ID: " + id);  // Thông báo nếu không tìm thấy sách
    }
}​08:30/-strong/-heart:>:o:-((:-h Xem trước khi gửiThả Files vào đây để xem lại trước khi gửi