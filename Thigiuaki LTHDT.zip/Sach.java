import.java.util.scanner;
 public class sach {
    private String id;
    private String ten sach;
    private String ten tac gia;
    private String ten nha xuat ban;

    public sach(int id, String tensach, String tentacgia, String tennhaxuatban) {
        this.id = id;
        this.tensach = tensach;
        this.tentacgia = tentacgia;
        this.tennhaxuatban = tennhaxuatban
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTensach() {
        return tensach;
    }

    public void setTensach(String tensach) {
        this.tensach = tensach;
    }
     
    public String gettentacgia() {
        return tentacgia;
    }

    public void settentacgia() {
        this.tentacgia = tentacgia;
    }

    public String getTennhaxuatban() {
        return getTennhaxuatban;
    }

    public void setTen(String tennhaxuatban) {
        this.tennhaxuatban = tennhaxuatban;
    }
    
    public String toString(){
        return "------------------ \n"+"Ma id: "+ id +", tenSach:" + tenSach +", tacGia:" + tacGia + ", nhaXuatBan" + nhaXuatban;
    }
}
        