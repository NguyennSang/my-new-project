import java.util.Scanner;

public class Main{
    public static void main(String[] args){
        Quanlysach manager = new Quanlysach();

        Scanner scanner = new Scanner (System.in);
        int choice;

        do{
            System.out.println("---------------");
            System.out.println("1.Hien thi danh sach cac quyen sach");
            System.out.println("2.Them sach vao danh sach");
            System.out.println("3.Sua thong tin sach theo ID");
            System.out.println("4.Thoat chuong trinh");
            System.out.println("0.Thoat");
            System.out.println("Chon:");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch(choice){
                case 1: 
                manager.hienthi();
                case 2: 
                System.out.print("Nhap ma ID cua sach:");String ID = scanner.nextLine();
                System.out.print("Nhap ten sach:");String tenSach = scanner.nextLine();
                System.out.print("Nhap ten tac gia:");String tacGia = scanner.nextLine();
                System.out.print("Nhap ten nha xuat ban:");String nhaXuatBan = scanner.nextLine();
                manager.addSach(new Sach(ID, tenSach, tacGia, nhaXuatBan));
                break;
                case 3:
                System.out.print("Nhap id sach can sua thong tin:");
                String updateId = scanner.nextLine();
                System.out.print("Nhap ten sach moi:");
                String newtenSach = scanner.nextLine();
                System.out.print("Nhap ten tac gia moi:");
                String newtacGia = scanner.nextLine();
                System.out.print("Nhap ten nhaXuatBan moi:");
                String newnhaXuatBan = scanner.nextLine();
                manager.updateSach(updateId, newtenSach, newtacGia, newnhaXuatBan);
                break;
                case 0:
                System.out.println("Thoat chuong trinh.");
                break;
                default:
                System.out.println("Lua chon khong hop le:");
            }
        }while (choice != 0 );
        scanner.close();
    }
}